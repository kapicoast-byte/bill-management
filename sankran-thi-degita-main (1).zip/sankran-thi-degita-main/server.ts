import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("invoices.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS outlets (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    address TEXT,
    country TEXT,
    currency TEXT
  );

  CREATE TABLE IF NOT EXISTS vendors (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT
  );

  CREATE TABLE IF NOT EXISTS invoices (
    id TEXT PRIMARY KEY,
    vendor_name TEXT,
    invoice_date TEXT,
    amount REAL,
    currency TEXT DEFAULT 'SGD',
    status TEXT DEFAULT 'pending',
    items TEXT,
    image_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Migration: Add missing columns if they don't exist
const tableInfo = db.prepare("PRAGMA table_info(invoices)").all() as any[];
const columns = tableInfo.map(c => c.name);

if (!columns.includes('vendor_id')) {
  db.exec("ALTER TABLE invoices ADD COLUMN vendor_id TEXT");
}
if (!columns.includes('outlet_id')) {
  db.exec("ALTER TABLE invoices ADD COLUMN outlet_id TEXT");
}
if (!columns.includes('tax_rate')) {
  db.exec("ALTER TABLE invoices ADD COLUMN tax_rate REAL");
}
if (!columns.includes('tax_amount')) {
  db.exec("ALTER TABLE invoices ADD COLUMN tax_amount REAL");
}
if (!columns.includes('service_charge')) {
  db.exec("ALTER TABLE invoices ADD COLUMN service_charge REAL");
}
if (!columns.includes('discount')) {
  db.exec("ALTER TABLE invoices ADD COLUMN discount REAL");
}

// Migration for outlets
const outletTableInfo = db.prepare("PRAGMA table_info(outlets)").all() as any[];
const outletColumns = outletTableInfo.map(c => c.name);
if (!outletColumns.includes('country')) {
  db.exec("ALTER TABLE outlets ADD COLUMN country TEXT");
}
if (!outletColumns.includes('currency')) {
  db.exec("ALTER TABLE outlets ADD COLUMN currency TEXT");
}

// Seed initial data if empty
const outletsCount = db.prepare("SELECT count(*) as count FROM outlets").get() as { count: number };
if (outletsCount.count === 0) {
  db.prepare("INSERT INTO outlets (id, name, address) VALUES (?, ?, ?)").run("o1", "Orchard Central Outlet", "181 Orchard Rd, Singapore 238896");
  db.prepare("INSERT INTO outlets (id, name, address) VALUES (?, ?, ?)").run("o2", "Marina Bay Sands Outlet", "10 Bayfront Ave, Singapore 018956");
}


async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // API Routes
  app.get("/api/outlets", (req, res) => {
    const outlets = db.prepare("SELECT * FROM outlets").all();
    res.json(outlets);
  });

  app.post("/api/outlets", (req, res) => {
    const { id, name, address, country, currency } = req.body;
    db.prepare("INSERT INTO outlets (id, name, address, country, currency) VALUES (?, ?, ?, ?, ?)").run(
      id || Math.random().toString(36).substr(2, 9), 
      name, 
      address,
      country || null,
      currency || null
    );
    res.status(201).json({ success: true });
  });

  app.put("/api/outlets/:id", (req, res) => {
    const { id } = req.params;
    const { name, address, country, currency } = req.body;
    try {
      db.prepare("UPDATE outlets SET name = ?, address = ?, country = ?, currency = ? WHERE id = ?").run(
        name, 
        address, 
        country || null,
        currency || null,
        id
      );
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update outlet" });
    }
  });

  app.delete("/api/outlets/:id", (req, res) => {
    const { id } = req.params;
    try {
      db.prepare("DELETE FROM outlets WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete outlet" });
    }
  });

  app.get("/api/vendors", (req, res) => {
    const vendors = db.prepare("SELECT * FROM vendors").all();
    res.json(vendors);
  });

  app.post("/api/vendors", (req, res) => {
    const { id, name, category } = req.body;
    db.prepare("INSERT INTO vendors (id, name, category) VALUES (?, ?, ?)").run(id || Math.random().toString(36).substr(2, 9), name, category);
    res.status(201).json({ success: true });
  });

  app.put("/api/vendors/:id", (req, res) => {
    const { id } = req.params;
    const { name, category } = req.body;
    try {
      db.prepare("UPDATE vendors SET name = ?, category = ? WHERE id = ?").run(name, category, id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update vendor" });
    }
  });

  app.delete("/api/vendors/:id", (req, res) => {
    const { id } = req.params;
    try {
      db.prepare("DELETE FROM vendors WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete vendor" });
    }
  });

  app.get("/api/invoices", (req, res) => {
    const { outlet_ids } = req.query;
    let queryStr = `
      SELECT i.*, o.name as outlet_name, v.name as linked_vendor_name, v.category 
      FROM invoices i
      LEFT JOIN outlets o ON i.outlet_id = o.id
      LEFT JOIN vendors v ON i.vendor_id = v.id
    `;
    
    const params: any[] = [];
    if (outlet_ids) {
      const ids = (outlet_ids as string).split(',');
      queryStr += ` WHERE i.outlet_id IN (${ids.map(() => '?').join(',')})`;
      params.push(...ids);
    }
    
    queryStr += ` ORDER BY i.created_at DESC`;
    
    const invoices = db.prepare(queryStr).all(...params);
    res.json(invoices.map(inv => ({
      ...inv,
      items: JSON.parse(inv.items as string)
    })));
  });

  app.post("/api/invoices", (req, res) => {
    const { id, vendor_id, vendor_name, outlet_id, invoice_date, amount, tax_rate, tax_amount, service_charge, discount, currency, items, image_url } = req.body;
    try {
      // Auto-create vendor if not exists by name? Or just link if ID provided
      let finalVendorId = vendor_id;
      if (!finalVendorId && vendor_name) {
        const existing = db.prepare("SELECT id FROM vendors WHERE name = ?").get(vendor_name) as { id: string } | undefined;
        if (existing) {
          finalVendorId = existing.id;
        } else {
          finalVendorId = 'v_' + Math.random().toString(36).substr(2, 9);
          db.prepare("INSERT INTO vendors (id, name) VALUES (?, ?)").run(finalVendorId, vendor_name);
        }
      }

      const stmt = db.prepare(`
        INSERT INTO invoices (
          id, vendor_id, vendor_name, outlet_id, invoice_date, 
          amount, tax_rate, tax_amount, service_charge, discount, 
          currency, items, image_url
        )
        VALUES (
          @id, @vendor_id, @vendor_name, @outlet_id, @invoice_date, 
          @amount, @tax_rate, @tax_amount, @service_charge, @discount, 
          @currency, @items, @image_url
        )
      `);
      
      stmt.run({
        id: id || `inv_${Math.random().toString(36).substr(2, 9)}`,
        vendor_id: finalVendorId || null,
        vendor_name: vendor_name || 'Unknown Vendor',
        outlet_id: outlet_id || null,
        invoice_date: invoice_date || new Date().toISOString().split('T')[0],
        amount: amount || 0,
        tax_rate: tax_rate || 0,
        tax_amount: tax_amount || 0,
        service_charge: service_charge || 0,
        discount: discount || 0,
        currency: currency || 'SGD',
        items: JSON.stringify(items || []),
        image_url: image_url || null
      });
      res.status(201).json({ success: true });
    } catch (error) {
      console.error("Database error:", error);
      res.status(500).json({ error: "Failed to save invoice" });
    }
  });

  app.patch("/api/invoices/:id/status", (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    try {
      const stmt = db.prepare("UPDATE invoices SET status = ? WHERE id = ?");
      stmt.run(status, id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update status" });
    }
  });

  app.delete("/api/invoices/:id", (req, res) => {
    const { id } = req.params;
    try {
      db.prepare("DELETE FROM invoices WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete invoice" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
