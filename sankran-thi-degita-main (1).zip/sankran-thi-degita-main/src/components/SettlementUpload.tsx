import React, { useState, useEffect } from 'react';
import { Upload, FileText, Loader2, Check, AlertCircle, Building2, Calendar, DollarSign } from 'lucide-react';
import { db, storage } from '../services/firebase';
import { collection, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Outlet, Settlement, UserProfile } from '../types';
import { motion } from 'motion/react';
import { extractSettlementData } from '../services/gemini';

interface SettlementUploadProps {
  onComplete: () => void;
  user: UserProfile | null;
}

export default function SettlementUpload({ onComplete, user }: SettlementUploadProps) {
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    outlet_id: '',
    date: new Date().toISOString().split('T')[0],
    total_sales: 0,
    cash_amount: 0,
    card_amount: 0,
    online_amount: 0,
    other_amount: 0
  });

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    fetchOutlets();
  }, [user]);

  const fetchOutlets = async () => {
    try {
      const res = await fetch('/api/outlets');
      const list = await res.json();
      
      let filteredList = list;
      if (user && user.role !== 'owner' && user.outlet_ids && user.outlet_ids.length > 0) {
        filteredList = list.filter((o: any) => user.outlet_ids.includes(o.id));
      }
      
      setOutlets(filteredList);
      if (filteredList.length > 0) {
        setFormData(prev => ({ ...prev, outlet_id: filteredList[0].id }));
      }
    } catch (err) {
      console.error('Error fetching outlets:', err);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        setPreview(base64);
        
        // Start AI extraction
        setExtracting(true);
        setError('');
        try {
          const data = await extractSettlementData(base64, selectedFile.type);
          setFormData(prev => ({
            ...prev,
            date: data.date || prev.date,
            total_sales: data.total_sales || 0,
            cash_amount: data.cash_amount || 0,
            card_amount: data.card_amount || 0,
            online_amount: data.online_amount || 0,
            other_amount: data.other_amount || 0
          }));
        } catch (err) {
          console.error('AI Extraction failed:', err);
          // We don't set error here to allow manual entry if AI fails
        } finally {
          setExtracting(false);
        }
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db || !storage) return;
    if (!formData.outlet_id) {
      setError('Please select an outlet');
      return;
    }

    setUploading(true);
    setError('');

    try {
      let imageUrl = '';
      if (file) {
        const fileRef = ref(storage, `settlements/${Date.now()}_${file.name}`);
        const uploadResult = await uploadBytes(fileRef, file);
        imageUrl = await getDownloadURL(uploadResult.ref);
      }

      const selectedOutlet = outlets.find(o => o.id === formData.outlet_id);

      await addDoc(collection(db, 'settlements'), {
        ...formData,
        outlet_name: selectedOutlet?.name || 'Unknown',
        status: 'pending',
        image_url: imageUrl,
        created_at: serverTimestamp()
      });

      setSuccess(true);
      setTimeout(() => {
        onComplete();
      }, 2000);
    } catch (err: any) {
      console.error('Error uploading settlement:', err);
      if (err.code === 'storage/unauthorized') {
        setError('Firebase Storage permission denied. Please check your Storage Rules in the Firebase Console.');
      } else {
        setError(err.message || 'Failed to upload settlement');
      }
    } finally {
      setUploading(false);
    }
  };

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mb-6">
          <Check className="w-10 h-10 text-emerald-600" />
        </div>
        <h3 className="text-2xl font-bold text-zinc-900 mb-2">Settlement Uploaded!</h3>
        <p className="text-zinc-500">The daily settlement has been recorded successfully.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Side: Upload */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
            <h3 className="text-lg font-bold text-zinc-900 mb-4 flex items-center gap-2">
              <Upload className="w-5 h-5 text-emerald-600" /> Upload Settlement Slip
            </h3>
            
            <div 
              className={`relative border-2 border-dashed rounded-2xl p-8 transition-all flex flex-col items-center justify-center text-center cursor-pointer ${
                preview ? 'border-emerald-200 bg-emerald-50/30' : 'border-zinc-200 hover:border-emerald-400 bg-zinc-50/50'
              }`}
              onClick={() => document.getElementById('settlement-file')?.click()}
            >
              <input 
                type="file" 
                id="settlement-file" 
                className="hidden" 
                accept="image/*" 
                onChange={handleFileChange}
              />
              
              {preview ? (
                <div className="relative w-full aspect-[3/4] rounded-xl overflow-hidden shadow-md">
                  <img src={preview} alt="Preview" className="w-full h-full object-cover" />
                  {extracting && (
                    <div className="absolute inset-0 bg-white/60 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center">
                      <Loader2 className="w-8 h-8 text-emerald-600 animate-spin mb-2" />
                      <p className="text-emerald-900 font-bold text-sm">AI Extracting Data...</p>
                      <p className="text-emerald-700 text-xs">Reading sales and payment breakdown</p>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <p className="text-white font-bold text-sm">Change Image</p>
                  </div>
                </div>
              ) : (
                <>
                  <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-4">
                    <FileText className="w-8 h-8 text-zinc-400" />
                  </div>
                  <p className="text-zinc-900 font-bold mb-1">Click to upload slip</p>
                  <p className="text-zinc-500 text-xs">PNG, JPG or PDF up to 10MB</p>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Form */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm space-y-4">
            <h3 className="text-lg font-bold text-zinc-900 mb-4 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-600" /> Settlement Details
            </h3>

            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Select Outlet</label>
              <select
                required
                value={formData.outlet_id}
                onChange={(e) => setFormData(prev => ({ ...prev, outlet_id: e.target.value }))}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
              >
                <option value="">Select an outlet...</option>
                {outlets.map(o => (
                  <option key={o.id} value={o.id}>{o.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Settlement Date</label>
              <div className="relative">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input
                  type="date"
                  required
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                  className="w-full pl-12 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                Total Sales ({outlets.find(o => o.id === formData.outlet_id)?.currency || 'SGD'})
              </label>
              <div className="relative">
                <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input
                  type="number"
                  step="0.01"
                  required
                  value={formData.total_sales}
                  onChange={(e) => setFormData(prev => ({ ...prev, total_sales: parseFloat(e.target.value) || 0 }))}
                  className="w-full pl-12 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-lg"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Cash</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.cash_amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, cash_amount: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none font-medium text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Card</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.card_amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, card_amount: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none font-medium text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Online</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.online_amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, online_amount: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none font-medium text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Other</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.other_amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, other_amount: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none font-medium text-sm"
                />
              </div>
            </div>

            {error && (
              <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3 text-red-600 text-sm font-medium">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={uploading}
              className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 disabled:opacity-70"
            >
              {uploading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Uploading Settlement...
                </>
              ) : (
                'Confirm & Save Settlement'
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
