import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { format, parseISO, startOfMonth, endOfMonth, eachMonthOfInterval, subMonths, isWithinInterval, startOfYear, endOfYear } from 'date-fns';
import { Invoice } from '../types';
import { Calendar, TrendingUp, PieChart as PieChartIcon, Filter, ArrowUpRight, ArrowDownRight, Plus } from 'lucide-react';

interface Props {
  invoices: Invoice[];
  onUpload: () => void;
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

export function ExpenseReports({ invoices, onUpload }: Props) {
  const [timeframe, setTimeframe] = useState<'6m' | '1y' | 'all'>('6m');

  const approvedInvoices = useMemo(() => 
    invoices.filter(inv => inv.status === 'approved'),
    [invoices]
  );

  const monthlyData = useMemo(() => {
    const now = new Date();
    let start: Date;
    
    if (timeframe === '6m') start = subMonths(now, 5);
    else if (timeframe === '1y') start = startOfYear(now);
    else start = new Date(Math.min(...approvedInvoices.map(i => new Date(i.invoice_date).getTime())));

    const months = eachMonthOfInterval({
      start: startOfMonth(start),
      end: endOfMonth(now)
    });

    return months.map(month => {
      const monthStr = format(month, 'MMM yyyy');
      const total = approvedInvoices
        .filter(inv => {
          const invDate = parseISO(inv.invoice_date);
          return isWithinInterval(invDate, { start: startOfMonth(month), end: endOfMonth(month) });
        })
        .reduce((sum, inv) => sum + inv.amount, 0);

      return {
        name: monthStr,
        amount: total
      };
    });
  }, [approvedInvoices, timeframe]);

  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};
    approvedInvoices.forEach(inv => {
      const category = (inv as any).category || 'Uncategorized';
      categories[category] = (categories[category] || 0) + inv.amount;
    });

    return Object.entries(categories)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [approvedInvoices]);

  const vendorData = useMemo(() => {
    const vendors: Record<string, number> = {};
    approvedInvoices.forEach(inv => {
      const name = (inv as any).linked_vendor_name || inv.vendor_name;
      vendors[name] = (vendors[name] || 0) + inv.amount;
    });

    return Object.entries(vendors)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  }, [approvedInvoices]);

  const totalSpend = approvedInvoices.reduce((sum, inv) => sum + inv.amount, 0);
  const avgMonthly = totalSpend / (monthlyData.length || 1);
  const currency = approvedInvoices.length > 0 ? approvedInvoices[0].currency : 'SGD';

  if (approvedInvoices.length === 0) {
    return (
      <div className="space-y-8">
        <div className="flex justify-end">
          <button
            onClick={onUpload}
            className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
          >
            <Plus className="w-5 h-5" /> New Upload
          </button>
        </div>
        <div className="text-center py-20 bg-white rounded-3xl border border-zinc-100">
          <TrendingUp className="w-12 h-12 text-zinc-300 mx-auto mb-4" />
          <h3 className="text-zinc-900 font-medium">No analytics data yet</h3>
          <p className="text-zinc-500 text-sm">Approve some invoices to see your spending trends.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      {/* Header & Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-zinc-900">Expense Analytics</h2>
          <p className="text-zinc-500 text-sm">Insights from your approved invoices</p>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={onUpload}
            className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
          >
            <Plus className="w-5 h-5" /> New Upload
          </button>
          <div className="flex bg-zinc-100 p-1 rounded-xl border border-zinc-200">
            {[
              { id: '6m', label: 'Last 6 Months' },
              { id: '1y', label: 'This Year' },
              { id: 'all', label: 'All Time' }
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTimeframe(t.id as any)}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${timeframe === t.id ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
            </div>
            <span className="text-zinc-500 text-sm font-medium">Total Approved Spend</span>
          </div>
          <p className="text-3xl font-black text-zinc-900">{currency} {totalSpend.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            <span className="text-zinc-500 text-sm font-medium">Avg. Monthly Spend</span>
          </div>
          <p className="text-3xl font-black text-zinc-900">{currency} {avgMonthly.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center">
              <PieChartIcon className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-zinc-500 text-sm font-medium">Top Category</span>
          </div>
          <p className="text-3xl font-black text-zinc-900">{categoryData[0]?.name || 'N/A'}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Monthly Trend */}
        <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm">
          <h3 className="text-lg font-bold text-zinc-900 mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-600" /> Monthly Spending Trend
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f4f5" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#a1a1aa', fontSize: 12 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#a1a1aa', fontSize: 12 }}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number) => [`${currency} ${value.toLocaleString()}`, 'Amount']}
                />
                <Bar dataKey="amount" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Distribution */}
        <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm">
          <h3 className="text-lg font-bold text-zinc-900 mb-6 flex items-center gap-2">
            <PieChartIcon className="w-5 h-5 text-purple-600" /> Spending by Category
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number) => [`${currency} ${value.toLocaleString()}`, 'Total']}
                />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Vendors */}
        <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm lg:col-span-2">
          <h3 className="text-lg font-bold text-zinc-900 mb-6 flex items-center gap-2">
            <Filter className="w-5 h-5 text-blue-600" /> Top Suppliers by Volume
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {vendorData.map((vendor, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-zinc-50 border border-zinc-100">
                <p className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1 truncate">{vendor.name}</p>
                <p className="text-xl font-black text-zinc-900">{currency} {vendor.value.toLocaleString()}</p>
                <div className="mt-2 w-full bg-zinc-200 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-500 h-full rounded-full" 
                    style={{ width: `${(vendor.value / vendorData[0].value) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
