import React, { useState } from 'react';
import { Check, X, Trash2, Calendar, Building2, Receipt, AlertTriangle, MapPin, ArrowUpDown, ArrowUp, ArrowDown, History as HistoryIcon } from 'lucide-react';
import { Invoice } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface Props {
  invoices: Invoice[];
  onUpdateStatus: (id: string, status: 'pending' | 'approved' | 'rejected') => void;
  onDelete: (id: string) => void;
  defaultSortField?: SortField;
}

type SortField = 'date' | 'amount' | 'supplier' | 'month';
type SortOrder = 'asc' | 'desc';

export default function InvoiceList({ invoices, onUpdateStatus, onDelete, defaultSortField = 'date' }: Props) {
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [sortField, setSortField] = useState<SortField>(defaultSortField);
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'approved': return 'Approved';
      case 'rejected': return 'Rejected';
      default: return 'Pending Approval';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'rejected': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-amber-100 text-amber-700 border-amber-200';
    }
  };

  const sortedInvoices = [...invoices].sort((a, b) => {
    if (sortField === 'date') {
      const dateA = new Date(a.invoice_date).getTime();
      const dateB = new Date(b.invoice_date).getTime();
      return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
    } else if (sortField === 'month') {
      const dateA = new Date(a.invoice_date);
      const dateB = new Date(b.invoice_date);
      const monthA = dateA.getFullYear() * 12 + dateA.getMonth();
      const monthB = dateB.getFullYear() * 12 + dateB.getMonth();
      if (monthA !== monthB) {
        return sortOrder === 'asc' ? monthA - monthB : monthB - monthA;
      }
      const nameA = ((a as any).linked_vendor_name || a.vendor_name).toLowerCase();
      const nameB = ((b as any).linked_vendor_name || b.vendor_name).toLowerCase();
      if (nameA !== nameB) {
        return sortOrder === 'asc' ? nameA.localeCompare(nameB) : nameB.localeCompare(nameA);
      }
      return sortOrder === 'asc' ? dateA.getTime() - dateB.getTime() : dateB.getTime() - dateA.getTime();
    } else if (sortField === 'amount') {
      return sortOrder === 'asc' ? a.amount - b.amount : b.amount - a.amount;
    } else {
      const nameA = ((a as any).linked_vendor_name || a.vendor_name).toLowerCase();
      const nameB = ((b as any).linked_vendor_name || b.vendor_name).toLowerCase();
      return sortOrder === 'asc' ? nameA.localeCompare(nameB) : nameB.localeCompare(nameA);
    }
  });

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  if (invoices.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-3xl border border-zinc-100">
        <Receipt className="w-12 h-12 text-zinc-300 mx-auto mb-4" />
        <h3 className="text-zinc-900 font-medium">No invoices found</h3>
        <p className="text-zinc-500 text-sm">Go to the <span className="text-emerald-600 font-bold">Upload & Analytics</span> tab to digitize your documents.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between px-4">
        <h2 className="text-zinc-900 font-semibold">Recent Invoices</h2>
        <div className="flex items-center gap-2">
          <div className="flex bg-zinc-100 p-1 rounded-xl border border-zinc-200">
            <button
              onClick={() => toggleSort('date')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${sortField === 'date' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
            >
              Date {sortField === 'date' && (sortOrder === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />)}
            </button>
            <button
              onClick={() => toggleSort('month')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${sortField === 'month' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
            >
              Month {sortField === 'month' && (sortOrder === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />)}
            </button>
            <button
              onClick={() => toggleSort('amount')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${sortField === 'amount' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
            >
              Amount {sortField === 'amount' && (sortOrder === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />)}
            </button>
            <button
              onClick={() => toggleSort('supplier')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${sortField === 'supplier' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
            >
              Supplier {sortField === 'supplier' && (sortOrder === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />)}
            </button>
          </div>
          <span className="text-zinc-500 text-sm ml-2">{invoices.length} total</span>
        </div>
      </div>

      <div className="grid gap-4">
        {sortedInvoices.map((invoice) => (
          <motion.div
            layout
            key={invoice.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-6 rounded-2xl border border-zinc-100 shadow-sm hover:shadow-md transition-shadow group"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-zinc-50 rounded-xl flex items-center justify-center border border-zinc-100">
                  <Building2 className="w-6 h-6 text-zinc-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-zinc-900 font-semibold group-hover:text-emerald-600 transition-colors">
                      {(invoice as any).linked_vendor_name || invoice.vendor_name}
                    </h3>
                    {(invoice as any).category && (
                      <span className="text-[10px] bg-zinc-100 text-zinc-500 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                        {(invoice as any).category}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-sm text-zinc-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {invoice.invoice_date}
                    </span>
                    {(invoice as any).outlet_name && (
                      <span className="flex items-center gap-1 text-emerald-600 font-medium">
                        <MapPin className="w-3 h-3" /> {(invoice as any).outlet_name}
                      </span>
                    )}
                    <span>ID: {invoice.id}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between md:justify-end gap-6">
                <div className="text-right">
                  <p className="text-zinc-900 font-bold text-lg">
                    {invoice.currency} {invoice.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(invoice.status)}`}>
                    {getStatusLabel(invoice.status)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-zinc-50 p-1 rounded-xl border border-zinc-100">
                    <button
                      onClick={() => onUpdateStatus(invoice.id, 'pending')}
                      disabled={invoice.status === 'pending'}
                      className={`p-2 rounded-lg transition-all ${invoice.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'text-zinc-400 hover:text-amber-600 hover:bg-amber-50'}`}
                      title="Mark as Pending Approval"
                    >
                      <HistoryIcon className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => onUpdateStatus(invoice.id, 'approved')}
                      disabled={invoice.status === 'approved'}
                      className={`p-2 rounded-lg transition-all ${invoice.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 'text-zinc-400 hover:text-emerald-600 hover:bg-emerald-50'}`}
                      title="Mark as Approved"
                    >
                      <Check className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => onUpdateStatus(invoice.id, 'rejected')}
                      disabled={invoice.status === 'rejected'}
                      className={`p-2 rounded-lg transition-all ${invoice.status === 'rejected' ? 'bg-red-100 text-red-700' : 'text-zinc-400 hover:text-red-600 hover:bg-red-50'}`}
                      title="Mark as Rejected"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <button
                    onClick={() => setDeletingId(invoice.id)}
                    className="p-2 text-zinc-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Items Preview */}
            <div className="mt-4 pt-4 border-t border-zinc-50">
              <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                {invoice.items.slice(0, 3).map((item, idx) => (
                  <span key={idx} className="text-xs bg-zinc-50 text-zinc-600 px-2 py-1 rounded border border-zinc-100 whitespace-nowrap">
                    {item.quantity}x {item.description}
                  </span>
                ))}
                {invoice.items.length > 3 && (
                  <span className="text-xs text-zinc-400 px-2 py-1">+{invoice.items.length - 3} more</span>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deletingId && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeletingId(null)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl border border-zinc-100"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mb-6">
                  <AlertTriangle className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-zinc-900 mb-2">Delete Invoice?</h3>
                <p className="text-zinc-500 mb-8">
                  This action cannot be undone. This invoice will be permanently removed from your records.
                </p>
                <div className="flex gap-3 w-full">
                  <button
                    onClick={() => setDeletingId(null)}
                    className="flex-1 px-6 py-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-600 font-bold rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      onDelete(deletingId);
                      setDeletingId(null);
                    }}
                    className="flex-1 px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-colors shadow-lg shadow-red-100"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
