import React, { useState, useEffect } from 'react';
import { Building2, Plus, MapPin, Trash2, Loader2, Edit2, Check, X, Globe, Coins } from 'lucide-react';
import { Outlet } from '../types';
import { motion, AnimatePresence } from 'motion/react';

const COUNTRIES = [
  { name: 'Singapore', currency: 'SGD' },
  { name: 'Malaysia', currency: 'MYR' },
  { name: 'India', currency: 'INR' },
  { name: 'United Arab Emirates', currency: 'AED' },
  { name: 'United States', currency: 'USD' },
  { name: 'United Kingdom', currency: 'GBP' },
  { name: 'Australia', currency: 'AUD' },
  { name: 'Indonesia', currency: 'IDR' },
  { name: 'Thailand', currency: 'THB' },
  { name: 'Vietnam', currency: 'VND' },
  { name: 'Philippines', currency: 'PHP' },
];

const CURRENCIES = ['SGD', 'MYR', 'INR', 'AED', 'USD', 'GBP', 'AUD', 'IDR', 'THB', 'VND', 'PHP', 'EUR', 'JPY'];

export default function OutletManagement() {
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const [newOutlet, setNewOutlet] = useState({ name: '', address: '', country: 'Singapore', currency: 'SGD' });
  const [editOutlet, setEditOutlet] = useState({ name: '', address: '', country: '', currency: '' });

  useEffect(() => {
    fetchOutlets();
  }, []);

  const fetchOutlets = async () => {
    try {
      const res = await fetch('/api/outlets');
      const data = await res.json();
      setOutlets(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/outlets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOutlet),
      });
      if (res.ok) {
        setNewOutlet({ name: '', address: '', country: 'Singapore', currency: 'SGD' });
        setIsAdding(false);
        fetchOutlets();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCountryChange = (countryName: string, isEdit: boolean) => {
    const country = COUNTRIES.find(c => c.name === countryName);
    if (isEdit) {
      setEditOutlet(prev => ({ ...prev, country: countryName, currency: country?.currency || prev.currency }));
    } else {
      setNewOutlet(prev => ({ ...prev, country: countryName, currency: country?.currency || prev.currency }));
    }
  };

  const handleUpdate = async (id: string) => {
    try {
      const res = await fetch(`/api/outlets/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editOutlet),
      });
      if (res.ok) {
        setEditingId(null);
        fetchOutlets();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const startEditing = (outlet: Outlet) => {
    setEditingId(outlet.id);
    setEditOutlet({ 
      name: outlet.name, 
      address: outlet.address || '', 
      country: outlet.country || 'Singapore', 
      currency: outlet.currency || 'SGD' 
    });
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/outlets/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setConfirmingId(null);
        fetchOutlets();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-zinc-900">Outlet Management</h2>
          <p className="text-zinc-500">Manage your restaurant locations</p>
        </div>
        <button
          onClick={() => setIsAdding(true)}
          className="bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-700 transition-all"
        >
          <Plus className="w-4 h-4" /> Add Outlet
        </button>
      </div>

      {isAdding && (
        <motion.form
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleAdd}
          className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm space-y-4"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-400 uppercase">Outlet Name</label>
              <input
                required
                type="text"
                value={newOutlet.name}
                onChange={(e) => setNewOutlet({ ...newOutlet, name: e.target.value })}
                className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                placeholder="e.g. Orchard Outlet"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-400 uppercase">Address</label>
              <input
                type="text"
                value={newOutlet.address}
                onChange={(e) => setNewOutlet({ ...newOutlet, address: e.target.value })}
                className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                placeholder="Full address"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-400 uppercase">Country</label>
              <select
                value={newOutlet.country}
                onChange={(e) => handleCountryChange(e.target.value, false)}
                className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {COUNTRIES.map(c => (
                  <option key={c.name} value={c.name}>{c.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-400 uppercase">Currency</label>
              <select
                value={newOutlet.currency}
                onChange={(e) => setNewOutlet({ ...newOutlet, currency: e.target.value })}
                className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {CURRENCIES.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 text-zinc-500 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-emerald-600 text-white px-6 py-2 rounded-lg font-bold"
            >
              Save Outlet
            </button>
          </div>
        </motion.form>
      )}

      <div className="grid gap-4">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
          </div>
        ) : outlets.map((outlet) => (
          <div key={outlet.id} className="bg-white p-6 rounded-2xl border border-zinc-100 shadow-sm">
            {editingId === outlet.id ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-400 uppercase">Outlet Name</label>
                    <input
                      type="text"
                      value={editOutlet.name}
                      onChange={(e) => setEditOutlet({ ...editOutlet, name: e.target.value })}
                      className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-400 uppercase">Address</label>
                    <input
                      type="text"
                      value={editOutlet.address}
                      onChange={(e) => setEditOutlet({ ...editOutlet, address: e.target.value })}
                      className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-400 uppercase">Country</label>
                    <select
                      value={editOutlet.country}
                      onChange={(e) => handleCountryChange(e.target.value, true)}
                      className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {COUNTRIES.map(c => (
                        <option key={c.name} value={c.name}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-400 uppercase">Currency</label>
                    <select
                      value={editOutlet.currency}
                      onChange={(e) => setEditOutlet({ ...editOutlet, currency: e.target.value })}
                      className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {CURRENCIES.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingId(null)}
                    className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors"
                    title="Cancel"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleUpdate(outlet.id)}
                    className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                    title="Save"
                  >
                    <Check className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-zinc-900">{outlet.name}</h3>
                    <div className="flex flex-wrap gap-x-4 gap-y-1">
                      <p className="text-sm text-zinc-500 flex items-center gap-1">
                        <MapPin className="w-3 h-3" /> {outlet.address || 'No address provided'}
                      </p>
                      {outlet.country && (
                        <p className="text-sm text-zinc-500 flex items-center gap-1">
                          <Globe className="w-3 h-3" /> {outlet.country}
                        </p>
                      )}
                      {outlet.currency && (
                        <p className="text-sm text-zinc-500 flex items-center gap-1">
                          <Coins className="w-3 h-3" /> {outlet.currency}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {confirmingId === outlet.id ? (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleDelete(outlet.id)}
                        className="px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-lg hover:bg-red-700 transition-all"
                      >
                        Confirm
                      </button>
                      <button
                        onClick={() => setConfirmingId(null)}
                        className="p-1 text-zinc-400 hover:text-zinc-600"
                        title="Cancel"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <button 
                        onClick={() => startEditing(outlet)}
                        className="p-2 text-zinc-400 hover:text-emerald-600 transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => setConfirmingId(outlet.id)}
                        className="p-2 text-zinc-400 hover:text-red-600 transition-colors" 
                        title="Delete"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
