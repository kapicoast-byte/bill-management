import React, { useState, useEffect } from 'react';
import { Check, X, Building2, Calendar, Receipt, DollarSign, List, Image as ImageIcon, Percent, MapPin, Truck, Tag, MinusCircle, PlusCircle } from 'lucide-react';
import { InvoiceFormData, Outlet, Vendor, UserProfile } from '../types';
import { motion } from 'motion/react';

interface Props {
  data: InvoiceFormData;
  imageUrl: string;
  onConfirm: (data: InvoiceFormData) => void;
  onCancel: () => void;
  user: UserProfile | null;
}

export default function InvoiceDetail({ data, imageUrl, onConfirm, onCancel, user }: Props) {
  const [isImageExpanded, setIsImageExpanded] = useState(false);
  const [formData, setFormData] = useState<InvoiceFormData>({
    ...data,
    tax_rate: data.tax_rate ?? 0,
    service_charge: data.service_charge ?? 0,
    discount: data.discount ?? 0,
  });
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);

  useEffect(() => {
    fetch('/api/outlets').then(res => res.json()).then(list => {
      if (user && user.role !== 'owner' && user.outlet_ids && user.outlet_ids.length > 0) {
        setOutlets(list.filter((o: any) => user.outlet_ids.includes(o.id)));
      } else {
        setOutlets(list);
      }
    });
    fetch('/api/vendors').then(res => res.json()).then(setVendors);
  }, [user]);

  const subtotal = formData.items.reduce((acc, item) => acc + (item.total || 0), 0);
  const taxAmount = subtotal * ((formData.tax_rate || 0) / 100);
  const totalAmount = subtotal + taxAmount + (formData.service_charge || 0) - (formData.discount || 0);

  // Sync calculated values back to formData for submission
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      tax_amount: taxAmount,
      amount: totalAmount
    }));
  }, [taxAmount, totalAmount]);

  const handleItemChange = (index: number, field: string, value: any) => {
    const newItems = [...formData.items];
    newItems[index] = { ...newItems[index], [field]: value };
    setFormData({ ...formData, items: newItems });
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 p-4 lg:p-6"
    >
      {/* Left: Invoice Image */}
      <div className={`
        relative bg-zinc-100 rounded-3xl overflow-hidden border border-zinc-200 lg:sticky lg:top-6 transition-all duration-300
        ${isImageExpanded ? 'h-[600px]' : 'h-[200px]'} lg:h-[calc(100vh-120px)]
      `}>
        <div className="absolute top-4 left-4 z-10 bg-white/80 backdrop-blur px-3 py-1.5 rounded-full flex items-center gap-2 text-sm font-medium text-zinc-700 shadow-sm">
          <ImageIcon className="w-4 h-4" /> Original Document
        </div>
        
        <button 
          onClick={() => setIsImageExpanded(!isImageExpanded)}
          className="lg:hidden absolute bottom-4 right-4 z-10 bg-white/90 backdrop-blur px-4 py-2 rounded-xl text-xs font-bold text-zinc-900 shadow-lg border border-zinc-100"
        >
          {isImageExpanded ? 'Collapse' : 'Expand Image'}
        </button>

        <img
          src={imageUrl}
          alt="Invoice"
          className="w-full h-full object-contain p-4"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Right: Extracted Data Form */}
      <div className="space-y-6">
        <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-xl">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-zinc-900">Review Data</h2>
            <div className="flex gap-2">
              <button
                onClick={onCancel}
                className="px-4 py-2 text-zinc-600 hover:bg-zinc-100 rounded-xl transition-colors font-medium flex items-center gap-2"
              >
                <X className="w-4 h-4" /> Cancel
              </button>
              <button
                onClick={() => onConfirm(formData)}
                className="px-6 py-2 bg-emerald-600 text-white hover:bg-emerald-700 rounded-xl transition-colors font-bold flex items-center gap-2 shadow-lg shadow-emerald-200"
              >
                <Check className="w-4 h-4" /> Save & Approve
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <Building2 className="w-3 h-3" /> Vendor Name
              </label>
              <input
                type="text"
                value={formData.vendor_name}
                onChange={(e) => setFormData({ ...formData, vendor_name: e.target.value })}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none font-medium"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <MapPin className="w-3 h-3" /> Assign to Outlet
              </label>
              <select
                value={formData.outlet_id || ''}
                onChange={(e) => setFormData({ ...formData, outlet_id: e.target.value })}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none font-medium appearance-none"
              >
                <option value="">Select Outlet</option>
                {outlets.map(o => (
                  <option key={o.id} value={o.id}>{o.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <Receipt className="w-3 h-3" /> Invoice ID
              </label>
              <input
                type="text"
                value={formData.id}
                onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none font-medium"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <Calendar className="w-3 h-3" /> Date
              </label>
              <input
                type="date"
                value={formData.invoice_date}
                onChange={(e) => setFormData({ ...formData, invoice_date: e.target.value })}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none font-medium"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <Percent className="w-3 h-3" /> Tax Rate (GST %)
              </label>
              <input
                type="number"
                value={formData.tax_rate}
                onChange={(e) => setFormData({ ...formData, tax_rate: parseFloat(e.target.value) })}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none font-medium"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <Truck className="w-3 h-3" /> Link to Vendor
              </label>
              <select
                value={formData.vendor_id || ''}
                onChange={(e) => {
                  const selectedVendor = vendors.find(v => v.id === e.target.value);
                  setFormData({ 
                    ...formData, 
                    vendor_id: e.target.value,
                    vendor_name: selectedVendor ? selectedVendor.name : formData.vendor_name 
                  });
                }}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none font-medium appearance-none"
              >
                <option value="">+ Create New or Auto-detect</option>
                {vendors.map(v => (
                  <option key={v.id} value={v.id}>{v.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <PlusCircle className="w-3 h-3" /> Service Charge / Delivery
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.service_charge}
                onChange={(e) => setFormData({ ...formData, service_charge: parseFloat(e.target.value) })}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none font-medium"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <MinusCircle className="w-3 h-3" /> Discount
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.discount}
                onChange={(e) => setFormData({ ...formData, discount: parseFloat(e.target.value) })}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none font-medium"
              />
            </div>
          </div>

          <div className="mt-8">
            <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2 mb-4">
              <List className="w-3 h-3" /> Line Items
            </label>
            <div className="space-y-3">
              {formData.items.map((item, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-3 items-center">
                  <div className="col-span-6">
                    <input
                      type="text"
                      value={item.description}
                      onChange={(e) => handleItemChange(idx, 'description', e.target.value)}
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-100 rounded-lg text-sm"
                      placeholder="Description"
                    />
                  </div>
                  <div className="col-span-2">
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => handleItemChange(idx, 'quantity', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-100 rounded-lg text-sm text-center"
                      placeholder="Qty"
                    />
                  </div>
                  <div className="col-span-4">
                    <input
                      type="number"
                      step="0.01"
                      value={item.total}
                      onChange={(e) => handleItemChange(idx, 'total', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-100 rounded-lg text-sm text-right font-medium"
                      placeholder="Total"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Breakdown Section */}
          <div className="mt-8 pt-8 border-t border-zinc-100 space-y-3">
            <div className="flex justify-between items-center text-zinc-500">
              <span className="text-sm font-medium">Subtotal</span>
              <span className="font-mono">{formData.currency} {subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between items-center text-zinc-500">
              <span className="text-sm font-medium flex items-center gap-2">
                Tax (GST {formData.tax_rate}%)
              </span>
              <span className="font-mono">{formData.currency} {taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
            {formData.service_charge ? (
              <div className="flex justify-between items-center text-zinc-500">
                <span className="text-sm font-medium">Service Charge / Delivery</span>
                <span className="font-mono">{formData.currency} {formData.service_charge.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
            ) : null}
            {formData.discount ? (
              <div className="flex justify-between items-center text-red-500">
                <span className="text-sm font-medium">Discount</span>
                <span className="font-mono">-{formData.currency} {formData.discount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
            ) : null}
            <div className="flex justify-between items-center pt-3 border-t border-zinc-50">
              <span className="text-lg font-bold text-zinc-900">Total Amount</span>
              <span className="text-2xl font-black text-emerald-600 font-mono">
                {formData.currency} {totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
