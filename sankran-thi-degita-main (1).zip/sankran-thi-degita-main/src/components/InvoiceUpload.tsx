import React, { useState, useRef } from 'react';
import { Upload, FileText, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { extractInvoiceData } from '../services/gemini';
import { InvoiceFormData } from '../types';

interface Props {
  onDataExtracted: (data: InvoiceFormData, imageUrl: string) => void;
}

export default function InvoiceUpload({ onDataExtracted }: Props) {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file (PNG, JPG).');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target?.result as string;
        try {
          const data = await extractInvoiceData(base64, file.type);
          if (data.is_invoice === false) {
            setError('This document does not appear to be an invoice or receipt.');
            setIsProcessing(false);
            return;
          }
          onDataExtracted(data, base64);
        } catch (err) {
          console.error(err);
          setError('Failed to extract data. Please try a clearer image.');
        } finally {
          setIsProcessing(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError('Error reading file.');
      setIsProcessing(false);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={onDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`
          relative border-2 border-dashed rounded-2xl p-12 transition-all cursor-pointer
          flex flex-col items-center justify-center gap-4
          ${isDragging ? 'border-emerald-500 bg-emerald-50/50' : 'border-zinc-200 hover:border-zinc-300 bg-white'}
          ${isProcessing ? 'pointer-events-none opacity-60' : ''}
        `}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={(e) => e.target.files?.[0] && processFile(e.target.files[0])}
          className="hidden"
          accept="image/*"
        />

        <AnimatePresence mode="wait">
          {isProcessing ? (
            <motion.div
              key="processing"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center gap-3"
            >
              <Loader2 className="w-12 h-12 text-emerald-500 animate-spin" />
              <p className="text-zinc-600 font-medium">AI is digitizing your invoice...</p>
              <p className="text-zinc-400 text-sm">Extracting vendors, items, and totals</p>
            </motion.div>
          ) : (
            <motion.div
              key="idle"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center gap-3"
            >
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center">
                <Upload className="w-8 h-8 text-emerald-600" />
              </div>
              <div className="text-center">
                <p className="text-zinc-900 font-semibold text-lg">Upload Invoice</p>
                <p className="text-zinc-500">Drag and drop or click to browse</p>
              </div>
              <p className="text-zinc-400 text-xs mt-2">Supports PNG, JPG, JPEG</p>
            </motion.div>
          )}
        </AnimatePresence>

        {error && (
          <div className="absolute -bottom-12 left-0 right-0 text-center">
            <p className="text-red-500 text-sm flex items-center justify-center gap-1">
              <X className="w-4 h-4" /> {error}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
