import React, { useState, useEffect } from 'react';
import { db, firebaseConfig, auth } from '../services/firebase';
import { collection, getDocs, doc, setDoc, deleteDoc, query, orderBy } from 'firebase/firestore';
import { initializeApp, deleteApp, getApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signOut as firebaseSignOut } from 'firebase/auth';
import { UserProfile, UserRole } from '../types';
import { UserPlus, Shield, Trash2, Mail, User as UserIcon, Loader2, Search, Check, X, Key, Building2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Outlet } from '../types';

export default function UserManagement() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [deletingUser, setDeletingUser] = useState<UserProfile | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  
  // New user form state
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('staff');
  const [newOutletIds, setNewOutletIds] = useState<string[]>([]);
  
  // Edit user state
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('staff');
  const [editOutletIds, setEditOutletIds] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchUsers();
    fetchOutlets();
  }, []);

  const fetchOutlets = async () => {
    try {
      const res = await fetch('/api/outlets');
      const data = await res.json();
      setOutlets(data);
    } catch (err) {
      console.error('Error fetching outlets:', err);
    }
  };

  const fetchUsers = async (showLoading = true) => {
    if (!db) return;
    if (showLoading) setLoading(true);
    try {
      const usersCol = collection(db, 'users');
      const userSnapshot = await getDocs(usersCol);
      const userList = userSnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          email: '', // Default if missing
          role: 'staff', // Default if missing
          ...data,
          uid: doc.id, // Use the document ID as the primary identifier for UI actions
          originalUid: data.uid // Keep the internal UID if it exists
        } as UserProfile;
      });
      setUsers(userList);
    } catch (err) {
      console.error('Error fetching users:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) return;
    setIsSubmitting(true);
    setError('');

    try {
      // 1. Create user in Firebase Authentication using a secondary app instance
      // This prevents the current admin session from being replaced by the new user
      const secondaryAppName = `secondary-app-${Date.now()}`;
      const secondaryApp = initializeApp(firebaseConfig, secondaryAppName);
      const secondaryAuth = getAuth(secondaryApp);
      
      const userCredential = await createUserWithEmailAndPassword(secondaryAuth, newEmail.toLowerCase(), newPassword);
      const uid = userCredential.user.uid;

      // Sign out the secondary app immediately
      await firebaseSignOut(secondaryAuth);
      await deleteApp(secondaryApp);

      // 2. Create the Firestore profile
      const userRef = doc(db, 'users', uid);
      await setDoc(userRef, {
        email: newEmail.toLowerCase(),
        role: newRole,
        uid: uid,
        outlet_ids: newOutletIds,
        createdAt: new Date().toISOString()
      });
      
      setNewEmail('');
      setNewPassword('');
      setNewRole('staff');
      setNewOutletIds([]);
      setIsAddingUser(false);
      fetchUsers();
    } catch (err: any) {
      console.error('Error adding user:', err);
      setError(err.message || 'Failed to add user');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db || !editingUser) return;
    setIsSubmitting(true);
    setError('');
    try {
      const userRef = doc(db, 'users', editingUser.uid);
      await setDoc(userRef, { 
        displayName: editName,
        role: editRole,
        outlet_ids: editOutletIds
      }, { merge: true });
      await fetchUsers(false);
      setEditingUser(null);
    } catch (err: any) {
      console.error('Error updating member:', err);
      setError(err.message || 'Failed to update member');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateRole = async (uid: string, role: UserRole) => {
    if (!db) return;
    setActionLoading(uid);
    try {
      const userRef = doc(db, 'users', uid);
      await setDoc(userRef, { role }, { merge: true });
      await fetchUsers(false);
    } catch (err: any) {
      console.error('Error updating role:', err);
      alert('Failed to update role: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeleteUser = async () => {
    if (!db || !deletingUser) return;
    
    // Prevent self-deletion
    if (deletingUser.uid === auth?.currentUser?.uid || deletingUser.originalUid === auth?.currentUser?.uid) {
      alert('You cannot remove your own account.');
      setDeletingUser(null);
      return;
    }

    setActionLoading(deletingUser.uid);
    try {
      await deleteDoc(doc(db, 'users', deletingUser.uid));
      await fetchUsers(false);
      setDeletingUser(null);
    } catch (err: any) {
      console.error('Error deleting user:', err);
      alert('Failed to delete member: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const filteredUsers = users.filter(u => 
    u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.displayName?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-zinc-900">Member Management</h1>
          <p className="text-zinc-500 text-sm">Manage access and roles for your restaurant staff</p>
        </div>
        <button
          onClick={() => setIsAddingUser(true)}
          className="flex items-center gap-2 bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
        >
          <UserPlus className="w-5 h-5" /> Add New Member
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-2xl border border-zinc-100 shadow-sm flex items-center gap-3">
        <Search className="w-5 h-5 text-zinc-400" />
        <input
          type="text"
          placeholder="Search by email or name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1 bg-transparent border-none outline-none text-sm font-medium"
        />
      </div>

      {/* User List */}
      <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-50 border-bottom border-zinc-100">
                <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Member</th>
                <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Role</th>
                <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {filteredUsers.map((user) => (
                <tr key={user.uid} className="hover:bg-zinc-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-zinc-100 rounded-xl flex items-center justify-center">
                        <UserIcon className="w-5 h-5 text-zinc-400" />
                      </div>
                      <div>
                        <p className="font-bold text-zinc-900">{user.displayName || user.email.split('@')[0]}</p>
                        <p className="text-xs text-zinc-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <select
                      value={user.role}
                      disabled={actionLoading === user.uid}
                      onChange={(e) => handleUpdateRole(user.uid, e.target.value as UserRole)}
                      className="bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-1.5 text-xs font-bold text-zinc-700 outline-none focus:ring-2 focus:ring-emerald-500 disabled:opacity-50"
                    >
                      <option value="owner">Owner</option>
                      <option value="manager">Manager</option>
                      <option value="staff">Staff</option>
                      <option value="account">Accountant</option>
                    </select>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1">
                      {user.role === 'owner' ? (
                        <span className="px-2 py-0.5 bg-zinc-100 text-zinc-600 rounded text-[10px] font-bold uppercase">All Outlets</span>
                      ) : user.outlet_ids && user.outlet_ids.length > 0 ? (
                        user.outlet_ids.map(oid => {
                          const outlet = outlets.find(o => o.id === oid);
                          return (
                            <span key={oid} className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded text-[10px] font-bold uppercase">
                              {outlet?.name || oid}
                            </span>
                          );
                        })
                      ) : (
                        <span className="px-2 py-0.5 bg-amber-50 text-amber-600 rounded text-[10px] font-bold uppercase">No Outlets</span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {actionLoading === user.uid ? (
                        <Loader2 className="w-5 h-5 text-emerald-500 animate-spin" />
                      ) : (
                        <>
                          <button
                            onClick={() => {
                              setEditingUser(user);
                              setEditName(user.displayName || '');
                              setEditRole(user.role);
                              setEditOutletIds(user.outlet_ids || []);
                            }}
                            className="p-2 text-zinc-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all"
                            title="Edit Member"
                          >
                            <Shield className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => setDeletingUser(user)}
                            className="p-2 text-zinc-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                            title="Delete Member"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filteredUsers.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-6 py-12 text-center">
                    <div className="flex flex-col items-center gap-2 text-zinc-400">
                      <Search className="w-8 h-8 opacity-20" />
                      <p className="text-sm font-medium">No members found matching your search</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add User Modal */}
      <AnimatePresence>
        {isAddingUser && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddingUser(false)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
                <h3 className="text-xl font-bold text-zinc-900">Add New Member</h3>
                <button onClick={() => setIsAddingUser(false)} className="p-2 text-zinc-400 hover:bg-zinc-50 rounded-xl transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleAddUser} className="p-6 space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                    <Mail className="w-3 h-3" /> Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                    placeholder="staff@restaurant.com"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                    <Key className="w-3 h-3" /> Set Password
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                    placeholder="••••••••"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                    <Shield className="w-3 h-3" /> Assign Role
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {(['manager', 'staff', 'account', 'owner'] as UserRole[]).map((role) => (
                      <button
                        key={role}
                        type="button"
                        onClick={() => setNewRole(role)}
                        className={`px-4 py-3 rounded-xl border text-sm font-bold transition-all ${
                          newRole === role
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-700 shadow-sm'
                            : 'bg-white border-zinc-200 text-zinc-500 hover:border-zinc-300'
                        }`}
                      >
                        {role.charAt(0).toUpperCase() + role.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                {newRole !== 'owner' && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                      <Building2 className="w-3 h-3" /> Assign Outlets
                    </label>
                    <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto p-1">
                      {outlets.map((outlet) => (
                        <button
                          key={outlet.id}
                          type="button"
                          onClick={() => {
                            if (newOutletIds.includes(outlet.id)) {
                              setNewOutletIds(newOutletIds.filter(id => id !== outlet.id));
                            } else {
                              setNewOutletIds([...newOutletIds, outlet.id]);
                            }
                          }}
                          className={`flex items-center justify-between px-4 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                            newOutletIds.includes(outlet.id)
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                              : 'bg-zinc-50 border-zinc-100 text-zinc-500 hover:border-zinc-200'
                          }`}
                        >
                          {outlet.name}
                          {newOutletIds.includes(outlet.id) && <Check className="w-4 h-4" />}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {error && (
                  <p className="text-red-500 text-xs font-medium text-center">{error}</p>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Create Member Profile'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit User Modal */}
      <AnimatePresence>
        {editingUser && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingUser(null)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
                <h3 className="text-xl font-bold text-zinc-900">Edit Member</h3>
                <button onClick={() => setEditingUser(null)} className="p-2 text-zinc-400 hover:bg-zinc-50 rounded-xl transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdateUser} className="p-6 space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                    <UserIcon className="w-3 h-3" /> Display Name
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                    placeholder="John Doe"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                    <Shield className="w-3 h-3" /> Update Role
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {(['manager', 'staff', 'account', 'owner'] as UserRole[]).map((role) => (
                      <button
                        key={role}
                        type="button"
                        onClick={() => setEditRole(role)}
                        className={`px-4 py-3 rounded-xl border text-sm font-bold transition-all ${
                          editRole === role
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-700 shadow-sm'
                            : 'bg-white border-zinc-200 text-zinc-500 hover:border-zinc-300'
                        }`}
                      >
                        {role.charAt(0).toUpperCase() + role.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                {editRole !== 'owner' && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                      <Building2 className="w-3 h-3" /> Assign Outlets
                    </label>
                    <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto p-1">
                      {outlets.map((outlet) => (
                        <button
                          key={outlet.id}
                          type="button"
                          onClick={() => {
                            if (editOutletIds.includes(outlet.id)) {
                              setEditOutletIds(editOutletIds.filter(id => id !== outlet.id));
                            } else {
                              setEditOutletIds([...editOutletIds, outlet.id]);
                            }
                          }}
                          className={`flex items-center justify-between px-4 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                            editOutletIds.includes(outlet.id)
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                              : 'bg-zinc-50 border-zinc-100 text-zinc-500 hover:border-zinc-200'
                          }`}
                        >
                          {outlet.name}
                          {editOutletIds.includes(outlet.id) && <Check className="w-4 h-4" />}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {error && (
                  <p className="text-red-500 text-xs font-medium text-center">{error}</p>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Save Changes'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deletingUser && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeletingUser(null)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden p-8 text-center"
            >
              <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-zinc-900 mb-2">Remove Member?</h3>
              <p className="text-zinc-500 text-sm mb-8">
                Are you sure you want to remove <span className="font-bold text-zinc-900">{deletingUser.email}</span>? This action cannot be undone.
              </p>

              <div className="flex flex-col gap-3">
                <button
                  onClick={handleDeleteUser}
                  disabled={!!actionLoading}
                  className="w-full bg-red-600 text-white py-3 rounded-xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-100 flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {actionLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Yes, Remove Member'}
                </button>
                <button
                  onClick={() => setDeletingUser(null)}
                  disabled={!!actionLoading}
                  className="w-full bg-zinc-100 text-zinc-600 py-3 rounded-xl font-bold hover:bg-zinc-200 transition-all"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
