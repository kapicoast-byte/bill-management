import React, { useState, useEffect } from 'react';
import { db } from '../services/firebase';
import { collection, getDocs, query, orderBy, where, deleteDoc, doc } from 'firebase/firestore';
import { storage } from '../services/firebase';
import { ref, deleteObject } from 'firebase/storage';
import { Settlement, Outlet, UserProfile } from '../types';
import { Search, Calendar, Building2, DollarSign, FileText, Loader2, Filter, Trash2, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

interface Props {
  user: UserProfile | null;
}

export default function SettlementList({ user }: Props) {
  const [settlements, setSettlements] = useState<Settlement[]>([]);
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOutlet, setSelectedOutlet] = useState('all');
  const [deletingSettlement, setDeletingSettlement] = useState<Settlement | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    fetchData();
  }, [user]);

  const fetchData = async () => {
    if (!db) return;
    setLoading(true);
    try {
      const settlementsCol = collection(db, 'settlements');
      let q = query(settlementsCol, orderBy('created_at', 'desc'));
      
      // Filter by user's outlets if not owner
      if (user && user.role !== 'owner' && user.outlet_ids && user.outlet_ids.length > 0) {
        q = query(settlementsCol, where('outlet_id', 'in', user.outlet_ids), orderBy('created_at', 'desc'));
      }
      
      const snapshot = await getDocs(q);
      const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Settlement[];
      setSettlements(list);

      const res = await fetch('/api/outlets');
      const outletList = await res.json();
      
      // Also filter outlets dropdown if not owner
      if (user && user.role !== 'owner' && user.outlet_ids && user.outlet_ids.length > 0) {
        setOutlets(outletList.filter((o: any) => user.outlet_ids.includes(o.id)));
      } else {
        setOutlets(outletList);
      }
    } catch (err) {
      console.error('Error fetching settlements:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredSettlements = settlements.filter(s => {
    const matchesSearch = s.outlet_name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         s.date.includes(searchQuery);
    const matchesOutlet = selectedOutlet === 'all' || s.outlet_id === selectedOutlet;
    return matchesSearch && matchesOutlet;
  });

  const getCurrency = (outletId: string) => {
    const outlet = outlets.find(o => o.id === outletId);
    return outlet?.currency || 'SGD';
  };

  const handleDelete = async () => {
    if (!db || !deletingSettlement) return;

    setIsDeleting(true);
    try {
      // Delete from Firestore
      await deleteDoc(doc(db, 'settlements', deletingSettlement.id));

      // Delete image from Storage if exists
      if (deletingSettlement.image_url && storage) {
        try {
          const imageRef = ref(storage, deletingSettlement.image_url);
          await deleteObject(imageRef);
        } catch (storageErr) {
          console.error('Error deleting image from storage:', storageErr);
        }
      }

      // Update local state
      setSettlements(prev => prev.filter(s => s.id !== deletingSettlement.id));
      setDeletingSettlement(null);
    } catch (err) {
      console.error('Error deleting settlement:', err);
      alert('Failed to delete settlement. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
        <div>
          <h3 className="text-xl font-bold text-zinc-900">Daily Settlements</h3>
          <p className="text-zinc-500 text-sm">View and track daily sales settlements by outlet</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2 bg-zinc-50 px-4 py-2 rounded-xl border border-zinc-100 w-full sm:w-64">
            <Search className="w-4 h-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Search by date or outlet..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent border-none outline-none text-sm w-full font-medium"
            />
          </div>
          
          <div className="flex items-center gap-2 bg-zinc-50 px-4 py-2 rounded-xl border border-zinc-100 w-full sm:w-48">
            <Filter className="w-4 h-4 text-zinc-400" />
            <select
              value={selectedOutlet}
              onChange={(e) => setSelectedOutlet(e.target.value)}
              className="bg-transparent border-none outline-none text-sm w-full font-medium"
            >
              <option value="all">All Outlets</option>
              {outlets.map(o => (
                <option key={o.id} value={o.id}>{o.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredSettlements.map((s) => (
          <div key={s.id} className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm hover:border-emerald-200 transition-all group">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center group-hover:bg-emerald-600 transition-colors">
                  <FileText className="w-6 h-6 text-emerald-600 group-hover:text-white transition-colors" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-zinc-900">{s.outlet_name}</span>
                    <span className="px-2 py-0.5 bg-zinc-100 text-zinc-500 text-[10px] font-bold rounded-md uppercase">
                      {s.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-zinc-500 font-medium">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {format(new Date(s.date), 'dd MMM yyyy')}
                    </span>
                    {s.image_url && (
                      <a 
                        href={s.image_url} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-emerald-600 hover:underline flex items-center gap-1"
                      >
                        View Slip
                      </a>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-8">
                <div>
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Total Sales</p>
                  <p className="font-bold text-zinc-900">{getCurrency(s.outlet_id)} {s.total_sales.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Cash</p>
                  <p className="text-sm font-bold text-zinc-600">{s.cash_amount.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Card</p>
                  <p className="text-sm font-bold text-zinc-600">{s.card_amount.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Online</p>
                  <p className="text-sm font-bold text-zinc-600">{s.online_amount.toFixed(2)}</p>
                </div>
              </div>

              {user?.role === 'owner' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setDeletingSettlement(s)}
                    className="p-2 text-zinc-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                    title="Delete Settlement"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}

        {filteredSettlements.length === 0 && (
          <div className="bg-white py-20 rounded-3xl border border-zinc-100 text-center">
            <div className="w-16 h-16 bg-zinc-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-zinc-300" />
            </div>
            <h4 className="text-lg font-bold text-zinc-900 mb-1">No settlements found</h4>
            <p className="text-zinc-500 text-sm">Upload your first daily settlement to see it here.</p>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deletingSettlement && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isDeleting && setDeletingSettlement(null)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl border border-zinc-100"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mb-6">
                  <AlertTriangle className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-zinc-900 mb-2">Delete Settlement?</h3>
                <p className="text-zinc-500 mb-8">
                  This will permanently delete the settlement record for <span className="font-bold text-zinc-900">{deletingSettlement.outlet_name}</span> on <span className="font-bold text-zinc-900">{format(new Date(deletingSettlement.date), 'dd MMM yyyy')}</span>. This action cannot be undone.
                </p>
                <div className="flex gap-3 w-full">
                  <button
                    disabled={isDeleting}
                    onClick={() => setDeletingSettlement(null)}
                    className="flex-1 px-6 py-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-600 font-bold rounded-xl transition-colors disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={isDeleting}
                    onClick={handleDelete}
                    className="flex-1 px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-colors shadow-lg shadow-red-100 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isDeleting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Deleting...
                      </>
                    ) : (
                      'Delete'
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
