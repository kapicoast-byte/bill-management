import React, { useState, useEffect } from 'react';
import { Truck, Plus, Tag, Trash2, Loader2, Edit2, Check, X } from 'lucide-react';
import { Vendor } from '../types';
import { motion, AnimatePresence } from 'motion/react';

export default function VendorManagement() {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const [newVendor, setNewVendor] = useState({ name: '', category: '' });
  const [editVendor, setEditVendor] = useState({ name: '', category: '' });

  useEffect(() => {
    fetchVendors();
  }, []);

  const fetchVendors = async () => {
    try {
      const res = await fetch('/api/vendors');
      const data = await res.json();
      setVendors(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/vendors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newVendor),
      });
      if (res.ok) {
        setNewVendor({ name: '', category: '' });
        setIsAdding(false);
        fetchVendors();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdate = async (id: string) => {
    try {
      const res = await fetch(`/api/vendors/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editVendor),
      });
      if (res.ok) {
        setEditingId(null);
        fetchVendors();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const startEditing = (vendor: Vendor) => {
    setEditingId(vendor.id);
    setEditVendor({ name: vendor.name, category: vendor.category || '' });
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/vendors/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setConfirmingId(null);
        fetchVendors();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-zinc-900">Vendor Directory</h2>
          <p className="text-zinc-500">Manage your suppliers and service providers</p>
        </div>
        <button
          onClick={() => setIsAdding(true)}
          className="bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-700 transition-all"
        >
          <Plus className="w-4 h-4" /> Add Vendor
        </button>
      </div>

      {isAdding && (
        <motion.form
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleAdd}
          className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm space-y-4"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-400 uppercase">Vendor Name</label>
              <input
                required
                type="text"
                value={newVendor.name}
                onChange={(e) => setNewVendor({ ...newVendor, name: e.target.value })}
                className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                placeholder="e.g. Fresh Seafood SG"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-400 uppercase">Category</label>
              <input
                type="text"
                value={newVendor.category}
                onChange={(e) => setNewVendor({ ...newVendor, category: e.target.value })}
                className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                placeholder="e.g. Seafood, Vegetables, Utilities"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 text-zinc-500 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-emerald-600 text-white px-6 py-2 rounded-lg font-bold"
            >
              Save Vendor
            </button>
          </div>
        </motion.form>
      )}

      <div className="grid gap-4">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
          </div>
        ) : vendors.map((vendor) => (
          <div key={vendor.id} className="bg-white p-6 rounded-2xl border border-zinc-100 shadow-sm">
            {editingId === vendor.id ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-400 uppercase">Vendor Name</label>
                    <input
                      type="text"
                      value={editVendor.name}
                      onChange={(e) => setEditVendor({ ...editVendor, name: e.target.value })}
                      className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-400 uppercase">Category</label>
                    <input
                      type="text"
                      value={editVendor.category}
                      onChange={(e) => setEditVendor({ ...editVendor, category: e.target.value })}
                      className="w-full px-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingId(null)}
                    className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors"
                    title="Cancel"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleUpdate(vendor.id)}
                    className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                    title="Save"
                  >
                    <Check className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-zinc-50 rounded-xl flex items-center justify-center">
                    <Truck className="w-6 h-6 text-zinc-400" />
                  </div>
                  <div>
                    <h3 className="font-bold text-zinc-900">{vendor.name}</h3>
                    <p className="text-sm text-zinc-500 flex items-center gap-1">
                      <Tag className="w-3 h-3" /> {vendor.category || 'Uncategorized'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {confirmingId === vendor.id ? (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleDelete(vendor.id)}
                        className="px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-lg hover:bg-red-700 transition-all"
                      >
                        Confirm
                      </button>
                      <button
                        onClick={() => setConfirmingId(null)}
                        className="p-1 text-zinc-400 hover:text-zinc-600"
                        title="Cancel"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <button 
                        onClick={() => startEditing(vendor)}
                        className="p-2 text-zinc-400 hover:text-emerald-600 transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => setConfirmingId(vendor.id)}
                        className="p-2 text-zinc-400 hover:text-red-600 transition-colors" 
                        title="Delete"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
