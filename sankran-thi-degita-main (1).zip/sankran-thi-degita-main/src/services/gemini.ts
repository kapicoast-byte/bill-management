import { GoogleGenAI, Type } from "@google/genai";
import { InvoiceFormData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function extractInvoiceData(base64Image: string, mimeType: string): Promise<InvoiceFormData> {
  const model = "gemini-3-flash-preview";
  
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image.split(',')[1],
            mimeType,
          },
        },
        {
          text: "Extract the invoice details from this image. Return a JSON object matching the schema. Identify the currency, tax rates (e.g., GST/VAT), service charges, delivery fees, and any discounts applied.",
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          is_invoice: { type: Type.BOOLEAN, description: "True if the document is an invoice or receipt, false otherwise." },
          id: { type: Type.STRING, description: "Invoice number or unique ID" },
          vendor_name: { type: Type.STRING },
          invoice_date: { type: Type.STRING, description: "Date in YYYY-MM-DD format" },
          amount: { type: Type.NUMBER, description: "Total amount including tax, service charges, and discounts" },
          tax_rate: { type: Type.NUMBER, description: "Tax rate in percentage (e.g., 9 for 9%)" },
          tax_amount: { type: Type.NUMBER, description: "Total tax amount" },
          service_charge: { type: Type.NUMBER, description: "Total service charge or delivery fee" },
          discount: { type: Type.NUMBER, description: "Total discount amount" },
          currency: { type: Type.STRING, description: "Currency code (e.g., SGD, MYR, USD)" },
          items: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                description: { type: Type.STRING },
                quantity: { type: Type.NUMBER },
                unit_price: { type: Type.NUMBER },
                total: { type: Type.NUMBER },
              },
              required: ["description", "total"],
            },
          },
        },
        required: ["is_invoice", "vendor_name", "amount", "items"],
      },
    },
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  return JSON.parse(text) as InvoiceFormData;
}

export async function extractSettlementData(base64Image: string, mimeType: string) {
  const model = "gemini-3-flash-preview";
  
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image.split(',')[1],
            mimeType,
          },
        },
        {
          text: "Extract the daily settlement details from this image. Identify the total sales and the breakdown by payment method (Cash, Card, Online/Digital, and Others). Return a JSON object matching the schema. The date should be in YYYY-MM-DD format.",
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          date: { type: Type.STRING, description: "Date in YYYY-MM-DD format" },
          total_sales: { type: Type.NUMBER, description: "Total sales amount" },
          cash_amount: { type: Type.NUMBER, description: "Amount paid in cash" },
          card_amount: { type: Type.NUMBER, description: "Amount paid by credit/debit card" },
          online_amount: { type: Type.NUMBER, description: "Amount paid via online/digital methods (Grab, Foodpanda, etc.)" },
          other_amount: { type: Type.NUMBER, description: "Any other payment amounts" },
        },
        required: ["date", "total_sales"],
      },
    },
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  return JSON.parse(text);
}
