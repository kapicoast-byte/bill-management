export type UserRole = 'owner' | 'manager' | 'staff' | 'account';

export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
  displayName?: string;
  originalUid?: string;
  outlet_ids?: string[];
}

export interface Outlet {
  id: string;
  name: string;
  address?: string;
  country?: string;
  currency?: string;
}

export interface Vendor {
  id: string;
  name: string;
  category?: string;
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  unit_price: number;
  total: number;
}

export interface Invoice {
  id: string;
  vendor_id?: string;
  vendor_name: string;
  outlet_id?: string;
  invoice_date: string;
  amount: number;
  tax_rate?: number;
  tax_amount?: number;
  service_charge?: number;
  discount?: number;
  currency: string;
  status: 'pending' | 'approved' | 'rejected';
  items: InvoiceItem[];
  image_url?: string;
  created_at?: string;
}

export type InvoiceFormData = Omit<Invoice, 'status' | 'created_at'> & { is_invoice?: boolean };

export interface Settlement {
  id: string;
  outlet_id: string;
  outlet_name: string;
  date: string;
  total_sales: number;
  cash_amount: number;
  card_amount: number;
  online_amount: number;
  other_amount?: number;
  status: 'pending' | 'verified';
  image_url?: string;
  created_at?: string;
  created_by?: string;
}
