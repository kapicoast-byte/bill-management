import React, { useState, useEffect } from 'react';
import { Plus, Receipt, Search, Filter, LayoutDashboard, Settings, LogOut, ChevronRight, Menu, Check, DollarSign, X, Building2, Truck, BarChart3, Lock, History as HistoryIcon, User as UserIcon, Shield, Loader2, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { auth, db, isFirebaseConfigured } from './services/firebase';
import Login from './components/Login';
import InvoiceUpload from './components/InvoiceUpload';
import SettlementUpload from './components/SettlementUpload';
import InvoiceList from './components/InvoiceList';
import InvoiceDetail from './components/InvoiceDetail';
import OutletManagement from './components/OutletManagement';
import VendorManagement from './components/VendorManagement';
import UserManagement from './components/UserManagement';
import SettlementList from './components/SettlementList';
import { ExpenseReports } from './components/ExpenseReports';
import { Invoice, InvoiceFormData, UserProfile, UserRole, Outlet } from './types';

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(isFirebaseConfigured);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadType, setUploadType] = useState<'invoice' | 'settlement'>('invoice');
  const [reviewData, setReviewData] = useState<{ data: InvoiceFormData; imageUrl: string } | null>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'vault' | 'outlets' | 'vendors' | 'reports' | 'configuration' | 'settlements'>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedOutletId, setSelectedOutletId] = useState<string>('all');

  useEffect(() => {
    if (!isFirebaseConfigured || !auth || !db) {
      setAuthLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const isDefaultOwner = firebaseUser.email === 'jayanthpasala10@gmail.com';
          let profile: UserProfile | null = null;

          // 1. Try lookup by UID
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (userDoc.exists()) {
            profile = { uid: firebaseUser.uid, email: firebaseUser.email!, ...userDoc.data() } as UserProfile;
          } else {
            // 2. Try lookup by Email (for invited users)
            const q = query(collection(db, 'users'), where('email', '==', firebaseUser.email?.toLowerCase()));
            const querySnapshot = await getDocs(q);
            if (!querySnapshot.empty) {
              const data = querySnapshot.docs[0].data();
              profile = { uid: firebaseUser.uid, email: firebaseUser.email!, ...data } as UserProfile;
              // Optional: Update the document to use UID as ID for future lookups
              // await setDoc(doc(db, 'users', firebaseUser.uid), data);
            }
          }
          
          if (profile) {
            // Ensure default owner always has owner role
            if (isDefaultOwner) profile.role = 'owner';
            setUser(profile);
            
            // Set initial tab based on role
            if (profile.role === 'staff') setActiveTab('reports');
            else if (profile.role === 'account') setActiveTab('vault');
            else setActiveTab('dashboard');
          } else {
            // Fallback if no profile exists yet
            const role: UserRole = isDefaultOwner ? 'owner' : 'staff';
            setUser({ uid: firebaseUser.uid, email: firebaseUser.email!, role });
            setActiveTab(role === 'owner' ? 'dashboard' : 'reports');
          }
        } catch (err) {
          console.error('Error fetching user profile:', err);
          setUser({ uid: firebaseUser.uid, email: firebaseUser.email!, role: 'staff' });
        }
      } else {
        setUser(null);
      }
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      fetchInvoices();
      fetchOutlets();
    }
  }, [user]);

  const fetchInvoices = async () => {
    try {
      let url = '/api/invoices';
      if (user && user.role !== 'owner' && user.outlet_ids && user.outlet_ids.length > 0) {
        url += `?outlet_ids=${user.outlet_ids.join(',')}`;
      }
      const res = await fetch(url);
      const data = await res.json();
      setInvoices(data);
    } catch (err) {
      console.error('Failed to fetch invoices:', err);
    }
  };

  const fetchOutlets = async () => {
    try {
      const res = await fetch('/api/outlets');
      const data = await res.json();
      if (user && user.role !== 'owner' && user.outlet_ids && user.outlet_ids.length > 0) {
        setOutlets(data.filter((o: any) => user.outlet_ids?.includes(o.id)));
      } else {
        setOutlets(data);
      }
    } catch (err) {
      console.error('Failed to fetch outlets:', err);
    }
  };

  const handleDataExtracted = (data: InvoiceFormData, imageUrl: string) => {
    setReviewData({ data, imageUrl });
    setIsUploading(false);
  };

  const handleConfirmInvoice = async (formData: InvoiceFormData) => {
    try {
      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, image_url: reviewData?.imageUrl }),
      });
      if (res.ok) {
        setReviewData(null);
        fetchInvoices();
      }
    } catch (err) {
      console.error('Failed to save invoice:', err);
    }
  };


  const handleUpdateStatus = async (id: string, status: 'pending' | 'approved' | 'rejected') => {
    try {
      const res = await fetch(`/api/invoices/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res.ok) fetchInvoices();
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };
  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/invoices/${id}`, { method: 'DELETE' });
      if (res.ok) fetchInvoices();
    } catch (err) {
      console.error('Failed to delete invoice:', err);
    }
  };

  const filteredInvoices = invoices.filter(inv => {
    const matchesFilter = filter === 'all' || inv.status === filter;
    const matchesSearch = inv.vendor_name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          inv.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesOutlet = selectedOutletId === 'all' || inv.outlet_id === selectedOutletId;
    return matchesFilter && matchesSearch && matchesOutlet;
  });

  const handleLogout = () => auth && signOut(auth);

  const canAccess = (tab: typeof activeTab) => {
    if (!user) return false;
    const { role } = user;
    if (role === 'owner') return true;
    if (role === 'manager') {
      return tab !== 'outlets' && tab !== 'vendors'; // Manager has everything except user/org management (outlets/vendors here)
    }
    if (role === 'staff') return tab === 'reports'; // Staff only upload (reports tab now handles upload)
    if (role === 'account') return tab === 'vault'; // Account only vault
    return false;
  };

  const dashboardInvoices = selectedOutletId === 'all' 
    ? invoices 
    : invoices.filter(i => i.outlet_id === selectedOutletId);

  const stats = {
    total: dashboardInvoices.length,
    pending: dashboardInvoices.filter(i => i.status === 'pending').length,
    approved: dashboardInvoices.filter(i => i.status === 'approved').length,
    totalAmount: dashboardInvoices.filter(i => i.status === 'approved').reduce((acc, curr) => acc + curr.amount, 0),
    currency: selectedOutletId !== 'all' 
      ? (outlets.find(o => o.id === selectedOutletId)?.currency || 'SGD')
      : (outlets.length > 0 ? (outlets.find(o => dashboardInvoices.some(i => i.outlet_id === o.id))?.currency || outlets[0].currency || 'SGD') : 'SGD')
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-emerald-500 animate-spin" />
      </div>
    );
  }

  if (!isFirebaseConfigured) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border border-zinc-100 text-center">
          <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Shield className="w-8 h-8 text-amber-600" />
          </div>
          <h1 className="text-2xl font-bold text-zinc-900 mb-2">Configuration Required</h1>
          <p className="text-zinc-500 mb-6">
            Please set up your Firebase environment variables in the project settings to enable secure authentication.
          </p>
          <div className="bg-zinc-50 p-4 rounded-xl text-left text-xs font-mono text-zinc-600 space-y-1">
            <p>VITE_FIREBASE_API_KEY</p>
            <p>VITE_FIREBASE_AUTH_DOMAIN</p>
            <p>VITE_FIREBASE_PROJECT_ID</p>
            <p>...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!user) return <Login />;

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex font-sans text-zinc-900 overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileMenuOpen(false)}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 w-64 bg-white border-r border-zinc-200 flex flex-col z-50 transition-transform duration-300 lg:relative lg:translate-x-0
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-100">
              <Receipt className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">Sankranti Digital</h1>
              <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Restaurant Management</p>
            </div>
          </div>
          <button onClick={() => setIsMobileMenuOpen(false)} className="lg:hidden p-2 text-zinc-400">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {canAccess('dashboard') && (
            <button
              onClick={() => { setActiveTab('dashboard'); setIsUploading(false); setReviewData(null); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'dashboard' && !isUploading && !reviewData ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50'}`}
            >
              <LayoutDashboard className="w-5 h-5" /> Dashboard
            </button>
          )}
          {canAccess('vault') && (
            <button
              onClick={() => { setActiveTab('vault'); setIsUploading(false); setReviewData(null); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'vault' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50'}`}
            >
              <Lock className="w-5 h-5" /> Vault
            </button>
          )}
          {canAccess('vault') && (
            <button
              onClick={() => { setActiveTab('settlements'); setIsUploading(false); setReviewData(null); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'settlements' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50'}`}
            >
              <FileText className="w-5 h-5" /> Settlements
            </button>
          )}
          {canAccess('reports') && (
            <button
              onClick={() => { setActiveTab('reports'); setIsUploading(false); setReviewData(null); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'reports' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50'}`}
            >
              <BarChart3 className="w-5 h-5" /> Upload & Analytics
            </button>
          )}
          
          {(canAccess('outlets') || canAccess('vendors')) && (
            <div className="pt-4 pb-2 px-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Management</div>
          )}
          
          {canAccess('outlets') && (
            <button
              onClick={() => { setActiveTab('outlets'); setIsUploading(false); setReviewData(null); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'outlets' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50'}`}
            >
              <Building2 className="w-5 h-5" /> Outlets
            </button>
          )}
          {canAccess('vendors') && (
            <button
              onClick={() => { setActiveTab('vendors'); setIsUploading(false); setReviewData(null); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'vendors' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50'}`}
            >
              <Truck className="w-5 h-5" /> Vendors
            </button>
          )}
          
          {user.role === 'owner' && (
            <>
              <div className="pt-4 pb-2 px-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Settings</div>
              <button 
                onClick={() => { setActiveTab('configuration'); setIsUploading(false); setReviewData(null); setIsMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'configuration' ? 'bg-emerald-50 text-emerald-700' : 'text-zinc-500 hover:bg-zinc-50'}`}
              >
                <Settings className="w-5 h-5" /> Configuration
              </button>
            </>
          )}
        </nav>

        <div className="p-4 border-t border-zinc-100">
          <div className="flex items-center gap-3 px-4 py-3 mb-2">
            <div className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center">
              <UserIcon className="w-4 h-4 text-zinc-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-zinc-900 truncate">{user.email}</p>
              <div className="flex flex-wrap gap-1 mt-0.5">
                <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-tighter">{user.role}</p>
                {user.role !== 'owner' && user.outlet_ids && user.outlet_ids.length > 0 && (
                  <span className="text-[9px] text-zinc-400 font-medium">
                    • {user.outlet_ids.length} Outlets
                  </span>
                )}
              </div>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-zinc-500 hover:bg-red-50 hover:text-red-600 transition-all font-medium"
          >
            <LogOut className="w-5 h-5" /> Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Header */}
        <header className="bg-white border-b border-zinc-200 px-8 py-4 flex items-center justify-between z-20">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden p-2 hover:bg-zinc-100 rounded-lg">
              <Menu className="w-6 h-6" />
            </button>
            <h2 className="text-xl font-bold text-zinc-900">
              {reviewData ? 'Review Invoice' : isUploading ? (uploadType === 'invoice' ? 'Digitize New Invoice' : 'Daily Settlement') : activeTab === 'vault' ? 'Approved Vault' : activeTab === 'outlets' ? 'Outlets' : activeTab === 'vendors' ? 'Vendors' : activeTab === 'reports' ? 'Upload & Analytics' : activeTab === 'configuration' ? 'Configuration' : activeTab === 'settlements' ? 'Settlements' : 'Dashboard'}
            </h2>
          </div>

          <div className="flex items-center gap-4">
            {activeTab === 'dashboard' && !reviewData && !isUploading && outlets.length > 0 && (
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-zinc-400" />
                <select
                  value={selectedOutletId}
                  onChange={(e) => setSelectedOutletId(e.target.value)}
                  className="bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-1.5 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                >
                  <option value="all">All Outlets</option>
                  {outlets.map(outlet => (
                    <option key={outlet.id} value={outlet.id}>{outlet.name}</option>
                  ))}
                </select>
              </div>
            )}
            {/* Global upload button removed as per user request */}
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-8 no-scrollbar">
          <AnimatePresence mode="wait">
            {reviewData ? (
              <InvoiceDetail
                data={reviewData.data}
                imageUrl={reviewData.imageUrl}
                onConfirm={handleConfirmInvoice}
                onCancel={() => setReviewData(null)}
                user={user}
              />
            ) : isUploading ? (
              <motion.div
                key="upload"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="max-w-4xl mx-auto pt-4 lg:pt-12"
              >
                <div className="mb-8 text-center">
                  <h2 className="text-3xl font-bold text-zinc-900 mb-2">
                    {uploadType === 'invoice' ? 'Upload Supplier Invoice' : 'Daily Settlement Upload'}
                  </h2>
                  <p className="text-zinc-500">
                    {uploadType === 'invoice' 
                      ? 'Our AI will automatically extract all data from your document.' 
                      : 'Record your daily sales and connect them to an outlet.'}
                  </p>
                </div>

                <div className="flex justify-center mb-12">
                  <div className="bg-zinc-100 p-1.5 rounded-2xl flex items-center gap-1">
                    <button
                      onClick={() => setUploadType('invoice')}
                      className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
                        uploadType === 'invoice' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
                      }`}
                    >
                      Invoice
                    </button>
                    <button
                      onClick={() => setUploadType('settlement')}
                      className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
                        uploadType === 'settlement' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
                      }`}
                    >
                      Settlement
                    </button>
                  </div>
                </div>

                {uploadType === 'invoice' ? (
                  <InvoiceUpload onDataExtracted={handleDataExtracted} />
                ) : (
                  <SettlementUpload onComplete={() => setIsUploading(false)} user={user} />
                )}

                <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    { title: 'Fast Processing', desc: 'Digitize in seconds' },
                    { title: 'High Accuracy', desc: 'Powered by Gemini AI' },
                    { title: 'Multi-Currency', desc: 'Handles SGD, MYR & more' }
                  ].map((f, i) => (
                    <div key={i} className="bg-white p-6 rounded-2xl border border-zinc-100 text-center">
                      <h4 className="font-bold text-zinc-900">{f.title}</h4>
                      <p className="text-zinc-500 text-sm">{f.desc}</p>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => setIsUploading(false)}
                  className="mt-8 mx-auto block text-zinc-400 hover:text-zinc-600 font-medium transition-colors"
                >
                  Back to Dashboard
                </button>
              </motion.div>
            ) : activeTab === 'outlets' ? (
              <OutletManagement key="outlets" />
            ) : activeTab === 'vendors' ? (
              <VendorManagement key="vendors" />
            ) : activeTab === 'configuration' ? (
              <UserManagement key="configuration" />
            ) : activeTab === 'settlements' ? (
              <SettlementList user={user} />
            ) : activeTab === 'vault' ? (
              <motion.div
                key="vault"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
                  <div>
                    <h3 className="text-xl font-bold text-zinc-900">Approved Vault</h3>
                    <p className="text-zinc-500 text-sm">Secure storage for all your finalized documents</p>
                  </div>
                  <div className="flex items-center gap-2 bg-zinc-50 px-4 py-2 rounded-xl border border-zinc-100 w-full md:w-96">
                    <Search className="w-4 h-4 text-zinc-400" />
                    <input
                      type="text"
                      placeholder="Search vault..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="bg-transparent border-none outline-none text-sm w-full font-medium"
                    />
                  </div>
                </div>

                <InvoiceList
                  invoices={invoices.filter(inv => 
                    inv.status === 'approved' && 
                    (inv.vendor_name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                     inv.id.toLowerCase().includes(searchQuery.toLowerCase()))
                  )}
                  onUpdateStatus={handleUpdateStatus}
                  onDelete={handleDelete}
                  defaultSortField="month"
                />
              </motion.div>
            ) : activeTab === 'reports' ? (
              <ExpenseReports invoices={invoices} onUpload={() => setIsUploading(true)} />
            ) : (
              <motion.div
                key={activeTab}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                {/* Stats Grid - Only show on Dashboard */}
                {activeTab === 'dashboard' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                    {[
                      { label: 'Total Invoices', value: stats.total, icon: Receipt, color: 'text-blue-600', bg: 'bg-blue-50' },
                      { label: 'Pending Approval', value: stats.pending, icon: HistoryIcon, color: 'text-amber-600', bg: 'bg-amber-50' },
                      { label: 'Approved', value: stats.approved, icon: Check, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                      { label: `Total Spend (${stats.currency})`, value: stats.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 }), icon: DollarSign, color: 'text-zinc-900', bg: 'bg-zinc-100' }
                    ].map((s, i) => (
                      <div key={i} className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
                        <div className="flex items-center gap-3 mb-4">
                          <div className={`w-10 h-10 ${s.bg} rounded-xl flex items-center justify-center`}>
                            <s.icon className={`w-5 h-5 ${s.color}`} />
                          </div>
                          <span className="text-zinc-500 text-sm font-medium">{s.label}</span>
                        </div>
                        <p className="text-2xl font-bold text-zinc-900">{s.value}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Filters & Search */}
                <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-white p-4 rounded-2xl border border-zinc-100 shadow-sm">
                  <div className="flex items-center gap-2 bg-zinc-50 px-4 py-2 rounded-xl border border-zinc-100 w-full md:w-96">
                    <Search className="w-4 h-4 text-zinc-400" />
                    <input
                      type="text"
                      placeholder="Search by vendor or ID..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="bg-transparent border-none outline-none text-sm w-full font-medium"
                    />
                  </div>
                  <div className="flex items-center gap-2 w-full md:w-auto">
                    <Filter className="w-4 h-4 text-zinc-400" />
                    <div className="flex bg-zinc-50 p-1 rounded-xl border border-zinc-100">
                      {(['all', 'pending', 'approved', 'rejected'] as const).map((f) => (
                        <button
                          key={f}
                          onClick={() => setFilter(f)}
                          className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filter === f ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
                        >
                          {f.toUpperCase()}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <InvoiceList
                  invoices={filteredInvoices}
                  onUpdateStatus={handleUpdateStatus}
                  onDelete={handleDelete}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
